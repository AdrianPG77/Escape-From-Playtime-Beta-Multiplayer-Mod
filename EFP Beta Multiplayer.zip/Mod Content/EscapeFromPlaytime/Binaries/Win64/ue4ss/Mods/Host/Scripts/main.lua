RegisterKeyBind(Key.F1, {}, function()
    ExecuteInGameThread(function()
        local PC = nil
        local controllers = FindAllOf("PlayerController")
        
        if controllers then
            for _, c in ipairs(controllers) do
                local ok, isValidPC = pcall(function()
                    return c:IsValid() and not string.find(c:GetFullName(), "Default__", 1, true)
                end)
                if ok and isValidPC then
                    PC = c
                    break
                end
            end
        end
        
        if not PC then return end
        
        local mapPath = "/Game/AEFPGame/Maps/00_Persistent/L_LabEscape"
        
        local success = pcall(function()
            PC:ClientTravel(mapPath .. "?listen", 0, true, {})
        end)
        
        if not success then
            local statics = StaticFindObject("/Script/Engine.Default__GameplayStatics")
            if statics then
                pcall(function()
                    statics:OpenLevel(PC, mapPath, true, "listen")
                end)
            end
        end
    end)
end)
