local PATHS = {
    "../../../../SetHostIP.ini",
    "../../../SetHostIP.ini",
    "../../SetHostIP.ini",
    "../SetHostIP.ini",
    "SetHostIP.ini"
}

local function GetHostIP()
    for _, path in ipairs(PATHS) do
        local file = io.open(path, "r")
        if file then
            for line in file:lines() do
                local ip = line:match("HostIP%s*=%s*([%d%.%:]+)") or line:match("([%d%.]+)")
                if ip and #ip >= 7 then
                    file:close()
                    return ip
                end
            end
            file:close()
        end
    end
    return nil
end

RegisterKeyBind(Key.F2, {}, function()
    ExecuteInGameThread(function()
        local ip = GetHostIP()
        if not ip then return end

        local controllers = FindAllOf("PlayerController")
        if not controllers then return end

        for _, PC in ipairs(controllers) do
            local ok, isValid = pcall(function()
                return PC:IsValid() and not string.find(PC:GetFullName(), "Default__")
            end)

            if ok and isValid then
                local executed = pcall(function()
                    PC:ConsoleCommand("open " .. ip, false)
                end)

                if not executed then
                    pcall(function()
                        PC:ClientTravel(ip, 0, false, {})
                    end)
                end
                break
            end
        end
    end)
end)