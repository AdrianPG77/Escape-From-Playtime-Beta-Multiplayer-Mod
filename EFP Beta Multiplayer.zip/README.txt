LEGAL DISCLAIMER & TERMS OF USE
This project is a non-profit, community-driven preservation and research tool designed exclusively for educational and personal modification purposes.

   1. No Ownership / No Infringement: This package does NOT contain, distribute, or host any proprietary files, assets, source code, executables (.exe), or media belonging to Mob Entertainment or its affiliates. All rights to "Escape From Playtime" and its assets belong entirely to their respective owners.
   2. Nature of the Mod: This modification functions exclusively as a runtime memory injection script using the open-source UE4SS framework. It does not modify, reverse engineer, or patch the game's original files on disk. It only exposes native Unreal Engine console commands (?listen) already present within the client's memory.
   3. No Commercial Use: This project is completely free of charge. No monetary gain, donations, or commercial benefits are derived from this software.
   4. User Responsibility: The end-user is entirely responsible for how they use this tool. The author of this script assumes no liability for any potential violations of the game's End User License Agreement (EULA) or Terms of Service (TOS) resulting from runtime memory modification, or for any action taken by the game's developers.

This project is not affiliated with, endorsed by, or connected to Mob Entertainment.